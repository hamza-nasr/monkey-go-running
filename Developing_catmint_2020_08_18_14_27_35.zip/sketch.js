var bananaImage, obstacleImage, obstacleGroup, back, score;

function preload(){
  backImage = loadImage("jungle.jpg");
  player_running =    loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage = loadImage("Banana.png");
  obstacle_img = loadImage("stone.png");
}
function setup() {
  createCanvas(400, 400);
  monkey = createSprite(100,300,20,20);
  monkey.addAnimation("player_running",monkey);
  
  back = createSprite(200,200,400,400);
  back.addAnimation("backImage",back);

  ground.visible = false;
  
}

function draw() {
 background("white");
  
  if(foodGroup.isTouching(monkey)){
     score = score+ 2;
    foodGroup.destroyEach;
     }
  drawSprites();
  
}