var bananaImage, obstacleImage, obstacleGroup, back, score;

function preload(){
  backImage = loadImage("jungle2.jpg");
  player_running =loadAnimation("Monkey_01.png",
                                    "Monkey_02.png",
                                    "Monkey_03.png",
                                    "Monkey_04.png",
                                    "Monkey_05.png",
                                    "Monkey_06.png",
                                    "Monkey_07.png",
                                    "Monkey_08.png",
                                    "Monkey_09.png",
                                    "Monkey_10.png");
  
  
  bananaImage = loadImage("banana.png");
  obstacle_img = loadImage("stone.png");
}
function setup() {
  createCanvas(400, 400);
  back = createSprite(200,200,400,400);
  back.addImage("backImage",backImage);
  back.x = back.width /2;

  
  monkey = createSprite(100,385,20,20);
  monkey.addAnimation("running",player_running);
  monkey.scale = 0.1;
 
 // fruit = createSprite(400,250,20,20);
 // fruit.addAnimation("banana", bananaImage);
  //fruit.scale = 0.05;
  
  ground = createSprite(90,385,400,20);
 // ground.visible = false;
  ground.visible = false;
  
  fruitGroup = createGroup();
  obstacleGroup = createGroup();
  
  score = 0;
}

function draw() {
 background("white");
 
  back.velocityX = -3;
 
 if (back.x < 0){
  back.x = back.width/2;
    }
  
  
  if (keyDown("space")){
    monkey.velocityY = -14;
      }
  
  if(fruitGroup.isTouching(monkey)){
     score = score + 3
    monkey.scale = monkey.scale + 0.01;
    fruitGroup.destroyEach();
     }

  if(obstacleGroup.isTouching(monkey)){
     score = score - 2
     monkey.scale = monkey.scale - 0.01;
    obstacleGroup.destroyEach();
     }
  
  spawnFruit();
  
  spawnObstacles();
   monkey.velocityY = monkey.velocityY + 0.8;

  
  
   monkey.collide(ground);
drawSprites();
  stroke("white");
  textSize(20)
  fill("white")
  text("Score: "+ score, 500,50);
}
function spawnFruit() {
  if(frameCount % 100 === 0) {
   fruit = createSprite(400,250,20,20);
   fruit.addAnimation("banana", bananaImage);
   fruit.scale = 0.05;
   fruit.velocityX = -6;
   fruitGroup.add(fruit) 
  }
}
function spawnObstacles(){
  if(frameCount % 150 === 0){
  obstacle = createSprite(400,385,20,20);
  obstacle.addAnimation("stone", obstacle_img);
  obstacle.scale = 0.3;
  obstacle.velocityX = -6;  
  obstacleGroup.add(obstacle);  
  }
}